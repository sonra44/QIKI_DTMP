# План миграции Legacy → gRPC для QIKI_DTMP (ИСПРАВЛЕННАЯ ВЕРСИЯ)

## КРИТИЧЕСКИЕ ИСПРАВЛЕНИЯ К ОРИГИНАЛЬНОМУ ПЛАНУ

### 🔧 **ТЕХНИЧЕСКОЕ ИСПРАВЛЕНИЕ 1: Protobuf типы**
**ПРОБЛЕМА:** Оригинальный план предлагал создать новые `BiosStatus` и `FsmState` в `q_sim_api.proto`, но эти типы УЖЕ СУЩЕСТВУЮТ.

**РЕШЕНИЕ:** Использовать существующие типы через import:
```proto
// В q_sim_api.proto добавить:
import "bios_status.proto";
import "fsm_state.proto";

service QSimAPI {
  rpc GetBiosStatus(google.protobuf.Empty) returns (qiki.bios.BiosStatusReport);
  rpc GetFsmState(google.protobuf.Empty) returns (qiki.fsm.FsmStateSnapshot);
}
```

### 🔧 **АРХИТЕКТУРНОЕ ИСПРАВЛЕНИЕ 2: FSM Handler**
**ПРОБЛЕМА:** FSM Handler интегрирован в Q-Core Agent и РАБОТАЕТ КОРРЕКТНО. Его перенос может сломать функциональность.

**АЛЬТЕРНАТИВНОЕ РЕШЕНИЕ:** Гибридный подход
- FSM Handler остается в Q-Core Agent (как есть)
- Q-Sim Service предоставляет только RAW FSM данные через gRPC
- Q-Core Agent обрабатывает переходы локально, но может синхронизировать состояние с сервером

### 🔧 **ПРОИЗВОДИТЕЛЬНОСТНОЕ ИСПРАВЛЕНИЕ 3: Частота вызовов**
**ПРОБЛЕМА:** gRPC вызовы для каждого FSM перехода добавят latency.

**РЕШЕНИЕ:** Batch operations и streaming
```proto
rpc StreamFsmUpdates(stream FsmStateSnapshot) returns (stream FsmStateSnapshot);
```

---

## ПЕРЕСМОТРЕННЫЙ ПЛАН МИГРАЦИИ

### Этап 1: MVP - Sensors/Actuators (УЖЕ РАБОТАЕТ ✅)
**Статус:** ЗАВЕРШЕН - базовая функциональность работает

### Этап 2: BIOS через gRPC
**БЕЗОПАСНЫЙ этап - BIOS не критичен для runtime**

1. **Обновить q_sim_api.proto:**
```proto
import "bios_status.proto";
rpc GetBiosStatus(google.protobuf.Empty) returns (qiki.bios.BiosStatusReport);
```

2. **Добавить в q_sim_service.py метод:**
```python
def generate_bios_status(self) -> BiosStatusReport:
    # Переместить логику из grpc_data_provider
```

3. **Обновить grpc_data_provider.py:**
```python
def get_bios_status(self) -> BiosStatusReport:
    return self.stub.GetBiosStatus(Empty())
```

**КРИТЕРИЙ УСПЕХА:** BIOS данные в gRPC режиме идентичны Legacy режиму

### Этап 3: FSM - ГИБРИДНЫЙ подход (РЕКОМЕНДУЕТСЯ)
**ОСТОРОЖНО:** FSM критичен, не ломать работающий код

**ВАРИАНТ А (консервативный):** FSM Handler остается в Q-Core Agent
- gRPC передает только raw FSM события
- Обработка состояний остается локальной
- Минимальный риск regression

**ВАРИАНТ Б (полный gRPC):** Централизация FSM в Q-Sim Service
- ⚠️ ВЫСОКИЙ РИСК - может сломать текущую логику
- Требует полной переработки FSM архитектуры

**РЕКОМЕНДАЦИЯ:** Начать с Варианта А

### Этап 4: Proposals (необязательно)
**СТАТУС:** Низкий приоритет - Rule Engine пока не работает

---

## РИСК-АНАЛИЗ И БЕЗОПАСНОСТЬ

### 🟢 **НИЗКИЙ РИСК:**
- Этап 2 (BIOS) - BIOS не критичен во время выполнения

### 🟡 **СРЕДНИЙ РИСК:**
- Этап 3 Вариант А (гибрид) - FSM обработка остается локальной

### 🔴 **ВЫСОКИЙ РИСК:**
- Этап 3 Вариант Б (полный gRPC) - может сломать работающую FSM логику

### ⛔ **БЛОКЕРЫ:**
1. **Протоколы:** Нужно проверить совместимость всех .proto файлов
2. **Тестирование:** Нет comprehensive тестов для FSM переходов
3. **Rollback:** Сложный откат если что-то пойдет не так

---

## ТЕХНИЧЕСКИЙ ПЛАН ДЕЙСТВИЙ

### ШАГ 1: Протоколы (1-2 часа)
```bash
# Проверить все .proto файлы
find . -name "*.proto" -exec echo "=== {} ===" \; -exec cat {} \;

# Регенерировать protobuf классы после изменений
protoc --python_out=generated/ protos/*.proto
```

### ШАГ 2: BIOS миграция (2-4 часа)
1. Обновить q_sim_api.proto с import bios_status.proto
2. Добавить GetBiosStatus в grpc_server.py  
3. Переместить BIOS логику в q_sim_service.py
4. Обновить grpc_data_provider.py
5. Тестировать сравнением с Legacy режимом

### ШАГ 3: FSM анализ (4-6 часов)
1. Создать тесты для current FSM behavior
2. Анализ производительности gRPC vs local FSM
3. Прототип гибридного подхода
4. Принятие решения: гибрид или полная миграция

---

## КРИТЕРИИ ПРИНЯТИЯ РЕШЕНИЙ

### ИДТИ НА ПОЛНУЮ МИГРАЦИЮ если:
- ✅ Есть реальная потребность в distributed deployment
- ✅ Все comprehensive тесты написаны  
- ✅ Performance acceptable (< 10ms latency)
- ✅ Rollback план детализирован

### ОСТАТЬСЯ НА ГИБРИДЕ если:
- ❌ Нет urgent потребности в distributed архитектуре
- ❌ Performance impact значительный
- ❌ Риски превышают выгоды

---

## ЗАКЛЮЧЕНИЕ

**ГЛАВНОЕ ИЗМЕНЕНИЕ:** Консервативный подход вместо агрессивной миграции.

Оригинальный план от Gemini хорош стратегически, но содержит технические ошибки и недооценивает риски. Исправленный plan более реалистичен и безопасен.

**РЕКОМЕНДАЦИЯ:** Начать с Этапа 2 (BIOS) как безопасный proof-of-concept для отработки gRPC integration patterns.