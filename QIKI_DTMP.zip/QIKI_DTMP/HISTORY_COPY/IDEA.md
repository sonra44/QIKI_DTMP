Я внимательно всё просмотрел.

Моё мнение по итогам:

1. **FSM-проблема** — это не баг логики, а дефект логирования. FSMHandler переходит в `IDLE` корректно, но в логах отображается `BOOTING`, потому что в `main.py` берутся данные напрямую из `DataProvider`, а не из `agent.context`. Решение — править вывод, а саму механику FSM трогать не надо.

2. **gRPC** — стратегически верный путь. Он даёт масштабируемость, строгие контракты и позволяет разделить сервисы. Но текущая реализация не доделана: FSM состояние по gRPC не передаётся, а в Legacy всегда `BOOTING`. Чтобы перейти на gRPC, надо дописать серверную часть и передачу актуального состояния FSM.

3. **Gemini CLI** — теперь у тебя полностью рабочий локальный доступ с API ключом и проектом. Главная ценность — не экономия токенов, а независимая проверка изменений (QA), потому что второй ИИ смотрит свежим взглядом и ловит ошибки, которые я мог пропустить. Это особенно полезно для финализации задач и исключения “синдрома 50%”.

4. **Гибридная работа Claude + Gemini** — реально рабочая модель:

   * Claude готовит данные, код, логи.
   * Gemini валидирует, предлагает улучшения или дополнения.
   * Claude внедряет исправления.
     Такой цикл повышает качество и завершённость работы.

Если резюмировать — техническая база у тебя сейчас отличная: FSM можно привести в порядок за 5 минут, gRPC имеет смысл развивать, а дуэт с Gemini даёт сильную систему QA и планирования.

Хочешь, я сразу сделаю пошаговый план **Hot Test** для внедрения новой системы, где мы оба с Gemini пройдём полный цикл — от плана до финальной проверки?

Второй лог подтверждает вывод из первого файла:

1. **FSM** — факт перехода в `IDLE` есть, но отображение состояния в логах неконсистентно. Это не поломка самого автомата, а рассинхрон между внутренним состоянием и источником данных для вывода. Исправляется централизованным обновлением статуса в одном месте, чтобы CLI, gRPC и логи брали его из одного источника (`agent.context.state`).

2. **Legacy режим** — в логах видно, что при запуске без полного gRPC стека часть данных остаётся в дефолтных значениях (`BOOTING`, `UNKNOWN`). Это нормальное поведение для заглушек, но для тестов лучше либо прокидывать реальные значения, либо явно помечать их как `NOT_CONNECTED`, чтобы не путать с рабочим состоянием.

3. **Переход на gRPC** — опять видно, что gRPC-сервер запущен, но состояние FSM через него не передаётся. Пока мы не пробросим это, любой внешний клиент будет видеть устаревшие или неверные данные.

4. **Общая стабильность** — ошибок исполнения нет, но есть явная проблема с UX-слоем: разные части системы “живут в своих реальностях” и показывают разные статусы. Это опасно для диагностики и операторской работы, потому что можно неправильно оценить ситуацию.

Если хочешь, я могу сейчас сделать **схему согласования статусов** и план исправления, чтобы FSM, CLI, логи и gRPC всегда показывали одно и то же состояние без рассинхрона. Это займёт немного времени, но решит корень проблемы.

Ок. Делаем «единую правду» для статусов и убираем рассинхрон.

# План согласования статусов (FSM/CLI/gRPC/логи)

## 1) Архитектурный принцип

* **Single Source of Truth (SSOT):** единственный объект `StateStore` внутри Q-Core, в котором лежит текущее `FsmStateSnapshot` (+ метаданные).
* **Write-path (пишем один раз):** только `FSMHandler` меняет состояние → пишет в `StateStore` → публикует событие `StateChanged`.
* **Read-path (читаем отовсюду):** логи, CLI, gRPC-сервер, REST — **только** из `StateStore`. Прямых обращений к `DataProvider.get_fsm_state()` больше нет.

## 2) Договор о состоянии

* Состояние: `{version, ts_monotonic, source='fsm_handler', current_state, prev_state, reason, attrs}`.
* Нулевое состояние: `current_state=BOOTING, reason='COLD_START'` — выставляет `FSMHandler` один раз при init.
* Явные псевдосостояния для UX: `NOT_CONNECTED`, `DEGRADED`, `FAILED` (не путаются с BOOTING/IDLE).
* Версионирование: `version++` при каждом валидном переходе; читатели принимают только более «свежее».
* Идемпотентность: повторная доставка того же `version` — игнор.

## 3) Изменения в коде (точечно)

1. `q_core_agent/main.py`

   * Логирование заменяем на чтение из контекста/StateStore:
     `FSM: {MessageToDict(agent.context.fsm_state)}`.
   * Убираем логирование из `DataProvider` (для FSM/Proposals/BiOS).

2. `core/interfaces.py (QSimDataProvider)`

   * `get_fsm_state()` больше **не** возвращает BOOTING по умолчанию. Возвращает `None`/пустой снимок; финальное состояние берётся из `StateStore`.

3. `core/grpc_data_provider.py`

   * Реализуем получение сенсоров/пропоузалов как раньше, **но FSM не трогаем**. Он только читатель `StateStore`, без попыток «подменить» состояние.

4. `core/state_store.py` (новый модуль)

   * Потокобезопасное хранилище (`asyncio.Lock`/RLock).
   * `get() / set(snapshot) / subscribe()` (pub/sub через `asyncio.Queue`).
   * Валидация версий и времени.

5. `core/fsm_handler.py`

   * После вычисления перехода: `state_store.set(..)` и `context.fsm_state = snapshot`.

6. `core/tick_orchestrator.py`

   * Порядок: `update_from_provider()` → `handle_fsm()` → **publish to StateStore** → прочее.
   * Если `DataProvider` вернул `None/placeholder` для FSM — игнорируем (истина в `StateStore`).

7. `services/q_core_agent/grpc_server (новый сервис)`

   * `StateService.GetState()` → читает из `StateStore`.
   * `StateService.SubscribeState()` → стрим из pub/sub (server-streaming).

8. Протоколы (`.proto`)

   * Добавляем `version`, `monotonic_ts`, `reason`, `source`.
   * Вводим enum для псевдосостояний (`NOT_CONNECTED` и т. п.).

## 4) Тест-пакет (обязательный)

* **Unit (FSM):** таблица переходов, валидация `version` и `reason`.
* **Unit (StateStore):** гонки, двойная доставка, отставшие версии.
* **Integration:** запуск цикла тиков → проверка, что логи/CLI/gRPC возвращают **одно и то же** `version/state`.
* **Contract (gRPC):** `GetState/SubscribeState` стабильны по схеме.
* **Chaos:** задержки и дубликаты событий → читатели остаются консистентными.
* **UX-тест:** нулевой старт → BOOTING → IDLE, без «залипания» BOOTING в логах.

## 5) Горячий запуск (HOT TEST)

1. Feature-flag `STATESTORE_ENABLED=true`.
2. Старт демо → за 10–20 тиков собираем снапшоты из **трёх точек**:

   * логи Q-Core,
   * `grpc_cli GetState`,
   * CLI/REST (если есть).
3. Автоматически сравниваем: `state`, `version`, `ts_monotonic`. Все три источника обязаны совпасть по `version/state`.
4. Прогон нулевого старта и деградации (`NOT_CONNECTED`) — проверяем UX-метки.

## 6) Критерии приёмки (Definition of Done)

* В логах **нет** `FSM: BOOTING` после первого валидного перехода в IDLE.
* `GetState()` и логи показывают **одинаковые** `{state, version}` в любой момент.
* При обновлении сенсоров/глюках сетевого слоя состояние **не прыгает назад** (версионность защищает).
* Псевдосостояния (`NOT_CONNECTED/DEGRADED/FAILED`) отделены от BOOTING/IDLE/ACTIVE и корректно отображаются в интерфейсе.

## 7) Риски и защита

* **Раскол источника:** кто-то снова начнёт читать из `DataProvider`.
  → Линтер/тест: запрещаем прямые чтения FSM вне `StateStore`.
* **Гонки:** два писателя состояния.
  → Единственный писатель — `FSMHandler`; остальные READ-ONLY.
* **Долг миграции:** legacy-код на BOOTING.
  → временный адаптер, который мапит `None` → текущее из `StateStore`.

---

# Что сделаю сразу (минимальный патч)

1. Заменю логирование FSM в `q_core_agent/main.py` на `agent.context.fsm_state`.
2. Добавлю `StateStore` и переведу `FSMHandler` на запись в него.
3. Временно оставлю `DataProvider.get_fsm_state()` как `None`, чтобы никто не полагался на него.
4. Добавлю простейший `StateService.GetState()` (in-proc/mock) для HOT TEST.

Дальше — gRPC-стрим и полные тесты.

Готов применить минимальный патч и сразу прогнать HOT TEST.

Понял: **ставит сам Клод через запросы** — значит даю готовые патчи и команды, которые он применит пошагово (без ручного редактирования). Минимальный рабочий набор, чтобы убить рассинхрон FSM уже сегодня.

# TL;DR

1. Переносим “истину” FSM в `StateStore`.
2. Логи читают `agent.context.fsm_state`, не `DataProvider`.
3. `DataProvider.get_fsm_state()` временно возвращает `None`.
4. Прогоняем HOT TEST и сравниваем версии/состояния.

---

# 1) Патч логирования (main.py)

Заменяем чтение из провайдера на контекст агента.

```bash
applypatch <<'PATCH'
*** Begin Patch
*** Update File: services/q_core_agent/main.py
@@
-                    logger.info("--- Input Messages (Legacy) ---")
-                    logger.info(f"BIOS: {MessageToDict(data_provider.get_bios_status())}")
-                    logger.info(f"FSM: {MessageToDict(data_provider.get_fsm_state())}")
-                    logger.info(f"Proposals: {[MessageToDict(p) for p in data_provider.get_proposals()]}")
-                    logger.info(f"Sensor: {MessageToDict(data_provider.get_sensor_data())}")
+                    logger.info("--- Input Messages (Unified) ---")
+                    # читаем только из agent.context (источник истины)
+                    logger.info(f"BIOS: {MessageToDict(agent.context.bios_status)}")
+                    logger.info(f"FSM: {MessageToDict(agent.context.fsm_state)}")
+                    logger.info(f"Proposals: {[MessageToDict(p) for p in agent.context.proposals]}")
+                    logger.info(f"Sensor: {MessageToDict(data_provider.get_sensor_data())}")
*** End Patch
PATCH
```

---

# 2) Единое хранилище состояния (state\_store.py)

Потокобезопасный store + версия.

```bash
mkdir -p services/q_core_agent/core
applypatch <<'PATCH'
*** Begin Patch
*** Add File: services/q_core_agent/core/state_store.py
+import threading
+from typing import Optional
+
+class StateStore:
+    """
+    Single Source of Truth для FSM-состояния.
+    Писатель один — FSMHandler. Остальные — читатели.
+    """
+    def __init__(self):
+        self._lock = threading.RLock()
+        self._snapshot = None  # FsmStateSnapshot | None
+        self._version = 0
+
+    def get(self):
+        with self._lock:
+            return self._snapshot, self._version
+
+    def set(self, snapshot):
+        with self._lock:
+            # ожидаем у snapshot поле version (int); если нет — инкрементируем здесь
+            v = getattr(snapshot, "version", None)
+            if v is None:
+                self._version += 1
+                try:
+                    setattr(snapshot, "version", self._version)
+                except Exception:
+                    pass
+            else:
+                self._version = max(self._version + 1, v)
+            self._snapshot = snapshot
+            return self._version
+
+# Глобальный инстанс для процесса агента
+STATE_STORE = StateStore()
*** End Patch
PATCH
```

---

# 3) FSMHandler пишет в StateStore

После расчёта перехода — фиксируем снапшот в store и в контекст.

```bash
applypatch <<'PATCH'
*** Begin Patch
*** Update File: services/q_core_agent/core/fsm_handler.py
@@
-from .proto_types import FsmStateSnapshot
+from .proto_types import FsmStateSnapshot
+from .state_store import STATE_STORE
@@
     def process_state(self, snapshot: FsmStateSnapshot) -> FsmStateSnapshot:
         # ... существующая логика переходов ...
         updated = self._compute_transition(snapshot)
-        return updated
+        # запись "истины" в store
+        try:
+            STATE_STORE.set(updated)
+        except Exception:
+            pass
+        return updated
*** End Patch
PATCH
```

*(если у тебя метод называется `process_fsm_state` — патч применится аналогично; в противном случае Клод подставит точное имя при выполнении).*

---

# 4) Контекст агента читает из StateStore на чтении

Чтобы любой читатель всегда видел одно и то же.

```bash
applypatch <<'PATCH'
*** Begin Patch
*** Update File: services/q_core_agent/core/agent.py
@@
 from .proto_types import FsmStateSnapshot
+from .state_store import STATE_STORE
@@
     def _update_context(self, data_provider):
         # раньше тянули FSM из data_provider; теперь — только как seed
-        self.context.update_from_provider(data_provider)
+        self.context.update_from_provider(data_provider)
+        # перетираем FSM из провайдера "истиной" из STATE_STORE, если есть
+        try:
+            snapshot, _v = STATE_STORE.get()
+            if snapshot is not None:
+                self.context.fsm_state = snapshot
+        except Exception:
+            pass
*** End Patch
PATCH
```

---

# 5) DataProvider перестаёт «подменять» FSM

Временно возвращаем `None`/пустой снимок, чтобы никто не думал, что BOOTING — актуален.

```bash
applypatch <<'PATCH'
*** Begin Patch
*** Update File: services/q_core_agent/core/interfaces.py
@@
     def get_fsm_state(self) -> FsmStateSnapshot:
-        # Q-Sim doesn't manage FSM state, so we'll return proper initial BOOTING state
-        fsm_state = FsmStateSnapshot(
-            current_state=FSMStateEnum.BOOTING,
-            reason="LEGACY_PROVIDER_DEFAULT",
-        )
-        return fsm_state
+        # Истина в STATE_STORE; провайдер FSM не формирует.
+        return FsmStateSnapshot()  # пустышка; будет перезаписан FSMHandler/StateStore
*** End Patch
PATCH
```

*(если файл у тебя иной — укажи реальный путь; из логов ранее это `interfaces.py`/`QSimDataProvider`).*

---

# 6) Простой accessor для CLI/gRPC (не обязательно сегодня)

Минимальный модуль для чтения единого состояния (его могут вызывать CLI/HTTP/gRPC):

```bash
applypatch <<'PATCH'
*** Begin Patch
*** Add File: services/q_core_agent/core/state_access.py
+from .state_store import STATE_STORE
+from .proto_types import FsmStateSnapshot
+
+def get_current_state():
+    snap, ver = STATE_STORE.get()
+    return snap, ver
*** End Patch
PATCH
```

---

# 7) HOT TEST (быстрая проверка)

Скрипт поднимет демо, выдернет три чтения и сравнит.

```bash
mkdir -p scripts
cat > scripts/hot_test_statestore.sh <<'SH'
#!/usr/bin/env bash
set -euo pipefail

LOGDIR=".agent/logs/$(date +%Y-%m-%d)"
./scripts/run_qiki_demo.sh || true
sleep 3

# 1) читаем из логов последнюю строку FSM
LOGFILE=$(ls -1t ${LOGDIR}/q_core_agent.log | head -n1 2>/dev/null || true)
FSM_LOG=$(tac "$LOGFILE" | grep -m1 "FSM:" || echo "FSM: {}")

# 2) читаем из in-proc accessor (через маленький однострочный python)
FSM_ACC=$(python3 - <<'PY'
from services.q_core_agent.core.state_access import get_current_state
from google.protobuf.json_format import MessageToDict
snap, ver = get_current_state()
print({"version": getattr(snap, "version", None), "state": MessageToDict(snap)})
PY
)

# 3) читаем из контекста агента (однократно через small probe)
FSM_CTX=$(python3 - <<'PY'
from services.q_core_agent.core.state_store import STATE_STORE
from google.protobuf.json_format import MessageToDict
snap, ver = STATE_STORE.get()
print({"version": getattr(snap, "version", None), "state": MessageToDict(snap)})
PY
)

echo "--- HOT TEST ---"
echo "LOG: $FSM_LOG"
echo "ACC: $FSM_ACC"
echo "CTX: $FSM_CTX"
SH
chmod +x scripts/hot_test_statestore.sh
```

Запуск:

```bash
./scripts/hot_test_statestore.sh
```

**Ожидаемое:** в логе больше нет `BOOTING` после первого перехода; три источника показывают одинаковые `version/state`.

---

# 8) Риски и фиксация

* Если где-то ещё зовётся `data_provider.get_fsm_state()` для вывода — заменяем на контекст/StateStore (поиск: `grep -R "get_fsm_state" services/q_core_agent | cat`).
* Временно разрешаем пустые снапшоты до первого перехода FSM.
* Дальше можно нарастить gRPC `GetState/SubscribeState` — но для HOT TEST достаточно accessor’а.

---

# NB: безопасность ключей

В `CLAUDE.md` у тебя сохранён **API ключ Gemini** и **Project ID**. Это удобно, но опасно. Рекомендация:

* Перенести секреты в `.env` или `~/.bashrc`, а из `CLAUDE.md` удалить/заменить плейсхолдерами.
* Ротация ключа — по возможности после миграции.

---

Готово. Если устраивает — отдавай Клоду команду «применить патчи и запустить `scripts/hot_test_statestore.sh`». Если где-то путь/имя функции расходится, он подставит точные в процессе (номера строк не критичны — логика проста: **пишем из FSMHandler, читаем из контекста/StateStore**).


Да, я с этим разбором полностью согласен — он точный, по делу и без лишней дипломатии.
Если сжать его до ключевых точек для принятия решения, то:

### 🔴 Два абсолютных блокера

1. **Threading vs AsyncIO**
   Прямое смешивание `threading.RLock` с `asyncio` — это не «может быть опасно», а практически гарантированный дедлок в бою.
2. **Protobuf-мутация**
   Насильственное `setattr` на proto-объекте ломает внутреннюю модель сериализации. Это не просто «грязно», это может крашнуть gRPC или REST при первой же попытке отправить состояние.

### ⚠️ Остальные высокие риски

* **Циклические импорты** — особенно учитывая, что `fsm_handler`, `agent` и `proto_types` уже связаны через `TYPE_CHECKING`.
* **Single Point of Failure** — если StateStore падает, падает вся система.
* **Тайминг при записи** — ошибка между вычислением и записью приведёт к тихому рассинхрону.

### 🛡 Вывод

* В текущем виде план из `IDEA.md` **невнедряем** — он полезен как концепт, но опасен для живой системы.
* Безопасный путь — **минимальный патч логирования** и, максимум, рефактор чтения FSM в одном месте, без внедрения StateStore в ядро.
* Обязательно держать **план отката** (ветка-бэкап, переключение feature-flag), если решим двигаться дальше.

Если хочешь, я могу прямо на базе этого разбора собрать **альтернативный StateStore-дизайн**, который будет асинхронным (`asyncio.Lock`), без мутаций protobuf, с lazy-загрузкой, и без циклических импортов. Это уберёт оба блокера.

Принял. Делаем **безопасный** StateStore без дедлоков, без мутации protobuf и без циклических импортов. Ниже — минимальный, но правильный дизайн + пошаговый план внедрения, который Клод сможет применить патчами.

# 0) Принципы

* **Async-only:** только `asyncio`, никаких `threading.*`.
* **DTO вместо protobuf:** внутренняя “истина” хранится в лёгком `dataclass` (DTO). Конвертация в/из protobuf — на границах.
* **Внедрение зависимостей:** `store` передаём через конструктор в `FSMHandler`/`Agent`, **без** глобалов → нет циклических импортов.
* **Один писатель:** писать состояние может только `FSMHandler`. Все остальные — читатели.
* **События:** подписка через `asyncio.Queue`. gRPC-стрим читает из очереди.

---

# 1) Модель данных (DTO, не protobuf)

`services/q_core_agent/state/types.py`

```python
from dataclasses import dataclass
from enum import IntEnum
from typing import Optional
import time

class FsmState(IntEnum):
    BOOTING = 1
    IDLE    = 2
    ACTIVE  = 3
    FAILED  = 4

@dataclass(frozen=True)
class FsmSnapshotDTO:
    version: int
    state: FsmState
    prev_state: Optional[FsmState]
    reason: str
    ts_mono: float   # time.monotonic()
    ts_wall: float   # time.time()

def initial_snapshot() -> FsmSnapshotDTO:
    now = time.time()
    return FsmSnapshotDTO(
        version=0,
        state=FsmState.BOOTING,
        prev_state=None,
        reason="COLD_START",
        ts_mono=time.monotonic(),
        ts_wall=now,
    )
```

Плюс конвертеры (в отдельном модуле, чтобы не тащить protobuf внутрь стора):

`services/q_core_agent/state/conv.py`

```python
from .types import FsmSnapshotDTO, FsmState
from google.protobuf.json_format import MessageToDict, ParseDict
from services.q_core_agent.proto.fsm_pb2 import FsmStateSnapshot, FSMStateEnum

def dto_to_proto(dto: FsmSnapshotDTO) -> FsmStateSnapshot:
    d = {
        "currentState": int(dto.state),
        "previousState": int(dto.prev_state) if dto.prev_state is not None else 0,
        "reason": dto.reason,
        "version": dto.version,
        "timestamps": {"mono": dto.ts_mono, "wall": dto.ts_wall},
    }
    msg = FsmStateSnapshot()
    ParseDict(d, msg)
    return msg

def proto_to_dto(msg: FsmStateSnapshot) -> FsmSnapshotDTO:
    # Если где-то нужен обратный путь — редко
    raise NotImplementedError
```

> Важно: **никаких `setattr` на protobuf**. Только DTO внутри, protobuf — на границах.

---

# 2) Async StateStore (без глобалов)

`services/q_core_agent/state/store.py`

```python
import asyncio
from typing import Optional, List
from .types import FsmSnapshotDTO

class AsyncStateStore:
    def __init__(self, initial: Optional[FsmSnapshotDTO]=None):
        self._lock = asyncio.Lock()
        self._snap: Optional[FsmSnapshotDTO] = initial
        self._subs: List[asyncio.Queue] = []

    async def get(self) -> Optional[FsmSnapshotDTO]:
        async with self._lock:
            return self._snap

    async def set(self, snap: FsmSnapshotDTO) -> FsmSnapshotDTO:
        async with self._lock:
            # монотонность версий — контролирует автор (FSMHandler);
            # тут просто фиксируем и пушим
            self._snap = snap
            for q in list(self._subs):
                # не блокируемся; если переполнен — тихо дропнем (или используйте try_put_nowait)
                try:
                    q.put_nowait(snap)
                except Exception:
                    pass
            return self._snap

    async def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=64)
        async with self._lock:
            self._subs.append(q)
            if self._snap is not None:
                # моментальная первичная доставка
                try:
                    q.put_nowait(self._snap)
                except Exception:
                    pass
        return q

    async def unsubscribe(self, q: asyncio.Queue):
        async with self._lock:
            if q in self._subs:
                self._subs.remove(q)
```

---

# 3) Внедрение в FSMHandler (один писатель)

В конструктор `FSMHandler` добавляем `store: AsyncStateStore`. После вычисления перехода формируем **новый DTO** (не protobuf) и пишем `await store.set(dto)`.

Скелет патча:

```python
# services/q_core_agent/core/fsm_handler.py
from services.q_core_agent.state.types import FsmSnapshotDTO, FsmState
from services.q_core_agent.state.store import AsyncStateStore
import time

class FSMHandler:
    def __init__(self, store: AsyncStateStore):
        self._store = store

    async def process(self, current: FsmSnapshotDTO) -> FsmSnapshotDTO:
        # пример логики перехода; подставьте вашу
        next_state = FsmState.IDLE if current.state == FsmState.BOOTING else current.state
        dto = FsmSnapshotDTO(
            version=current.version + (1 if next_state != current.state else 0),
            state=next_state,
            prev_state=current.state if next_state != current.state else current.prev_state,
            reason="BOOT_COMPLETE" if next_state == FsmState.IDLE and current.state==FsmState.BOOTING else current.reason,
            ts_mono=time.monotonic(),
            ts_wall=time.time(),
        )
        await self._store.set(dto)
        return dto
```

> Никаких мутаций; создаём **новый** DTO.

---

# 4) Оркестратор/Агент: где читаем и чем наполняем контекст

* В `tick_orchestrator`:

  1. читаем текущий DTO из `store` (если `None` — берём `initial_snapshot()`),
  2. передаём в `FSMHandler.process(...)`,
  3. полученный DTO конвертируем в protobuf и кладём в `agent.context.fsm_state` **для логов/интерфейсов**.

Скелет:

```python
# services/q_core_agent/core/tick_orchestrator.py
from services.q_core_agent.state.types import initial_snapshot
from services.q_core_agent.state.conv import dto_to_proto

class TickOrchestrator:
    def __init__(self, agent, store):
        self.agent = agent
        self.store = store

    async def run_tick(self, data_provider):
        # 1) обновить прочие части контекста из провайдера
        await self.agent.update_from_provider(data_provider)

        # 2) текущее состояние
        current = await self.store.get() or initial_snapshot()

        # 3) обработать FSM
        updated = await self.agent.fsm_handler.process(current)

        # 4) отразить в контексте (protobuf для логов и API)
        self.agent.context.fsm_state = dto_to_proto(updated)
```

> Теперь **все логи** должны брать `agent.context.fsm_state`. Никаких вызовов `data_provider.get_fsm_state()` для логирования.

---

# 5) DataProvider

* Возврат `FSM` из провайдера **убираем** (или возвращаем пустышку). Истина — в `store` и контексте после конвертации.
* Сенсоры/Proposals — как раньше.

---

# 6) gRPC StateService (читатель)

* gRPC сервис (при необходимости) подписывается: `q = await store.subscribe()` и стримит снапшоты, конвертируя `dto → protobuf` **на выходе**.
* `GetState()` — однократное `await store.get()` с конвертацией.

---

# 7) Фича-флаг + откат

* `QIKI_USE_STATESTORE=true|false`.
* При `false` — старое поведение (только фикс логирования, если уже сделали).
* Бэкап-ветка и `git revert` готовы.

---

# 8) Тесты (минимум)

* **Unit FSM:** переход `BOOTING→IDLE`, рост `version`, неизменность без перехода.
* **Store:** конкурентные `set/get/subscribe`, переполненная очередь подписчиков не блокирует.
* **Integration:** 10–20 тиков → сравнение `agent.context.fsm_state` (protobuf) с `dto` из `store` → совпадение `state/version`.
* **Regression:** при падении между вычислением и записью (симулируем исключение) контекст не обновляется, `version` не прыгает назад.

---

# 9) Что делает Клод прямо сейчас (патчи по шагам)

1. **Добавить** модули `state/types.py`, `state/store.py`, `state/conv.py`.
2. Внедрить `AsyncStateStore` в конструкторы `FSMHandler`/`TickOrchestrator`/`Agent` (передача через DI, **без** глобалов).
3. Перевести `FSMHandler` на `async def process(...)` и запись через `await store.set(dto)`.
4. В `tick_orchestrator.run_tick` — читать DTO из стора, после `process` писать protobuf в `agent.context.fsm_state`.
5. В `main.py` — логировать **только** `agent.context.fsm_state`.
6. Убрать `data_provider.get_fsm_state()` из любых логов/UX.
7. Под флагом `QIKI_USE_STATESTORE=true` запускать новый путь; иначе — старый.

---

# 10) Почему это снимает все критические риски

* **Нет `threading` →** нет дедлоков с `asyncio`.
* **Нет мутации protobuf →** сериализация стабильна; protobuf создаётся заново из DTO.
* **Нет циклических импортов →** стора/DTO/конвертеры лежат в отдельном `state/*`, внедряются через конструктор.
* **Нет SPOF-глобала →** стор — обычный объект; можно иметь по одному на агент, можно заменить на распределённый позднее.
* **Окно тайминга минимальное →** даже при исключении в `process` контекст не обновится, `version` не сдвинется — система останется консистентной.

---

Хочешь — упакую это в **готовые патчи** (как раньше `applypatch`), чтобы Клод применил за один проход, и добавлю короткий `HOT TEST` (async), который сравнит `dto` и `agent.context.fsm_state` на каждом тике.


