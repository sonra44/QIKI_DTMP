# Оглавление Карты Проекта

- [/home/sonra44/QIKI_DTMP/run_gemini_auto.sh](./0_run_gemini_auto.sh.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/core/agent.py](./1_services_q_core_agent_core_agent.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/core/grpc_data_provider.py](./2_services_q_core_agent_core_grpc_data_provider.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/core/interfaces.py](./3_services_q_core_agent_core_interfaces.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/main.py](./4_services_q_core_agent_main.py.md)
- [/home/sonra44/QIKI_DTMP/scripts/hot_test_statestore.sh](./5_scripts_hot_test_statestore.sh.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/tests/test_stress.py](./6_services_q_core_agent_state_tests_test_stress.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/tests/test_integration.py](./7_services_q_core_agent_state_tests_test_integration.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/tests/test_conv.py](./8_services_q_core_agent_state_tests_test_conv.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/tests/test_store.py](./9_services_q_core_agent_state_tests_test_store.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/tests/test_types.py](./10_services_q_core_agent_state_tests_test_types.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/tests/__init__.py](./11_services_q_core_agent_state_tests___init__.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/core/tick_orchestrator.py](./12_services_q_core_agent_core_tick_orchestrator.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/core/fsm_handler.py](./13_services_q_core_agent_core_fsm_handler.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/conv.py](./14_services_q_core_agent_state_conv.py.md)
- [/home/sonra44/QIKI_DTMP/services/q_core_agent/state/store.py](./15_services_q_core_agent_state_store.py.md)


## Непроанализированные файлы

- [`/home/sonra44/QIKI_DTMP/README.md`](./UNANALYZED_README.md.md)
- [`/home/sonra44/QIKI_DTMP/requirements.txt`](./UNANALYZED_requirements.txt.md)
- [`/home/sonra44/QIKI_DTMP/services/q_sim_service/main.py`](./UNANALYZED_services_q_sim_service_main.py.md)
- [`/home/sonra44/QIKI_DTMP/protos/q_sim_api.proto`](./UNANALYZED_protos_q_sim_api.proto.md)