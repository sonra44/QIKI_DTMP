# Файл не проанализирован

**Путь:** `/home/sonra44/QIKI_DTMP/protos/q_sim_api.proto`

Этот документ еще не был добавлен в `PROJECT_MAP.md` и требует анализа.